#pragma once

#ifndef _AST_INDEX_H_
#define _AST_INDEX_H_

#include "ast.h"

size_t index(struct AST *root);

#endif /* _AST_INDEX_H_ */