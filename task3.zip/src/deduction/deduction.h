#pragma once

#ifndef _DEDUCTION_H_
#define _DEDUCTION_H_

#include <stdio.h>

void process_proof(FILE *in, FILE *out);

#endif