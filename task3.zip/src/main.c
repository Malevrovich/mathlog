#include "deduction.h"

#include <stdio.h>
#include <stdlib.h>

int main() {
    process_proof(stdin, stdout);
    return 0;
}