#pragma once

#ifndef _AST_LIST_H_
#define _AST_LIST_H_

#include "ast.h"
#include "list.h"

DECLARE_LIST(ast, struct AST*)

#endif